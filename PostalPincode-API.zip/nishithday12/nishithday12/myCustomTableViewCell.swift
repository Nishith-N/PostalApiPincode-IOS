//
//  myCustomTableViewCell.swift
//  nishithday12
//
//  Created by Apple on 16/06/22.
//  Copyright © 2022 Apple. All rights reserved.
//

import UIKit

class myCustomTableViewCell: UITableViewCell {

    @IBOutlet weak var postName: UILabel!
    
    @IBOutlet weak var deliveryStatus: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
