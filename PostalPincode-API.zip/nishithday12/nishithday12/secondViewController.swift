//
//  secondViewController.swift
//  nishithday12
//
//  Created by Apple on 16/06/22.
//  Copyright © 2022 Apple. All rights reserved.
//

import UIKit

class secondViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var link = "https://api.postalpincode.in/pincode/"
    var pin = ""
    var flag = 0
    var finalUrl = ""
    var reciever = ""
    var newData : [[String:Any]] = [[String:Any]]()
    var PostOffice : [[String:Any]] = [[String:Any]]()
    @IBOutlet weak var myTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.myTableView.delegate = self
        self.myTableView.dataSource = self
        self.getMethodAPI()
        self.pin = self.reciever
        self.link = self.link + self.pin
       
        print(pin)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       if(flag == 1)
        {
           return 1
       }
        
        return self.PostOffice.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 240
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCustomTableViewCell", for: indexPath) as! myCustomTableViewCell
        
        
        
        if(flag == 1)
        {
            cell.postName.text = "Error"
            cell.deliveryStatus.text = "None"
        }
        else{
            cell.postName.text = "\(self.PostOffice[indexPath.row]["Name"]!)"
            cell.deliveryStatus.text = "\(self.PostOffice[indexPath.row]["DeliveryStatus"]!)"
        }
        
        cell.postName.textColor = .red
        
        return cell
    }
    
    func getMethodAPI() {
        
        let url = URL(string: "https://api.postalpincode.in/pincode/\(self.reciever)")
        var urlReq = URLRequest(url: url!)
        print(self.link)
        urlReq.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: urlReq) { (data, response, error) in
            if let err = error{
                print(err)
                return
            }
            if let resp = response as? HTTPURLResponse{
                print(resp.statusCode)
            }
            do{
                self.newData = try JSONSerialization.jsonObject(with: data!, options: []) as! [[String:Any]]
                if((self.newData[0]["Status"]) as! String == "Error")
                {
                
                    self.flag=1
                }
                else
                {
                self.PostOffice = self.newData[0]["PostOffice"] as! [[String:Any]]
                }
            }
            catch let err as NSError{
                print(err.localizedDescription)
            }
            DispatchQueue.main.async {
                self.myTableView.reloadData()
            }
            
        }
        task.resume()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
