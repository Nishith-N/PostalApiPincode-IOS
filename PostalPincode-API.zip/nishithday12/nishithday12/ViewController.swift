//
//  ViewController.swift
//  nishithday12
//
//  Created by Apple on 16/06/22.
//  Copyright © 2022 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
   
    @IBOutlet weak var pincodeTextField: UITextField!
    
    @IBOutlet weak var myButton: UIButton!
    
    var sender: String!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        pincodeTextField.delegate = self
        pincodeTextField.keyboardType = .numberPad
        self.myButton.addTarget(self, action: #selector(buttonTap(sender:)), for: .touchUpInside)
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    @objc func buttonTap(sender: UIButton)
    {
        let vc = storyboard?.instantiateViewController(withIdentifier: "secondViewController") as! secondViewController
        
        
        self.sender = "\(self.pincodeTextField.text ?? "")"
        vc.reciever = self.sender
        navigationController?.pushViewController(vc, animated: true)
        
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let maxLength = 6
        let currentString: NSString = (textField.text ?? "") as NSString
        let newString: NSString =  currentString.replacingCharacters(in: range, with: string) as NSString
        
        return newString.length <= maxLength
    }
    
    
    
    
    
    
    

    


}

